# pass 0
# wrong lists

user_enter = input("Enter the first 7 characters of your NRIC/FIN: ")
weights = [2, 7, 6, 5, 4, 3, 2]
checksum = 0
lastletter = ''
SF_list = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'Z', 'J']
TG_list = ['K', 'L', 'M', 'N', 'P', 'Q', 'R', 'T', 'U', 'W', 'X']


for i in range(7):
    # print(weights[i]*int(user_enter[1:][i]))
    checksum += weights[i]*int(user_enter[1:][i])

# print(checksum)


if user_enter[0] == 'S' or user_enter[0] == 'F':
    checksum += 0

elif user_enter[0] == 'T' or user_enter[0] == 'G':
    checksum += 4

checksum = checksum % 11
# print(checksum)

if user_enter[0] == 'S' or user_enter[0] == 'F':
    lastletter = SF_list[checksum]

elif user_enter[0] == 'T' or user_enter[0] == 'G':
    lastletter = TG_list[checksum]

user_enter += lastletter

print("Your complete NRIC/FIN is: ", user_enter)