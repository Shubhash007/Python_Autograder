# pass 8
# hardcoded
# Define the weights for the calculation
weights = [2, 7, 6, 5, 4, 3, 2]

# Define the checksum letters for 'S' and 'F'
checksum_letters_s_f = ['J', 'Z', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A']

# Define the checksum letters for 'T' and 'G'
checksum_letters_t_g = ['G', 'F', 'E', 'D', 'C', 'B', 'A', 'J', 'Z', 'I', 'H']

# Get input from the user
nric_input = input("Enter the first 7 characters of your NRIC/FIN: ").strip().upper()

# Extract the first character to determine the category
first_char = nric_input[0]

# Manually extract each digit from the NRIC input as integers (no loops)
digit1 = int(nric_input[1])
digit2 = int(nric_input[2])
digit3 = int(nric_input[3])
digit4 = int(nric_input[4])
digit5 = int(nric_input[5])
digit6 = int(nric_input[6])
digit7 = int(nric_input[7])

# Calculate the weighted sum manually without loops
weighted_sum = (
    weights[0] * digit1 +
    weights[1] * digit2 +
    weights[2] * digit3 +
    weights[3] * digit4 +
    weights[4] * digit5 +
    weights[5] * digit6 +
    weights[6] * digit7
)

# Adjust the sum based on the first character
if first_char == 'T' or first_char == 'G':
    weighted_sum += 4

# Find the checksum index using modulo 11
checksum_index = weighted_sum % 11

# Determine the last alphabet based on the first character
if first_char == 'S' or first_char == 'F':
    checksum_letter = checksum_letters_s_f[checksum_index]
elif first_char == 'T' or first_char == 'G':
    checksum_letter = checksum_letters_t_g[checksum_index]
else:
    print("Invalid NRIC/FIN format.")
    checksum_letter = ""

# Print the full NRIC/FIN if valid
if checksum_letter:
    full_nric = nric_input + checksum_letter
    print("Your complete NRIC/FIN is: ", full_nric)
