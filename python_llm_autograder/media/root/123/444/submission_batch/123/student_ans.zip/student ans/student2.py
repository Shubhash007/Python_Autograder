# pass 2
# list comprehension method, no strip, no upper()
# prompt for input
user_input = input("Enter first 7 characters of NRIC/FIN: ")

# error handling for wrong length input
if len(user_input) != 8:
    print("NRIC/FIN is wrong length")
    exit()
    

# error handling for invalid NRIC characters
if user_input[0].upper() not in 'STFG':
    print("NRIC/FIN first character is invalid")
    

for i in user_input[1:]:
    if i not in "0123456789":
        print("NRIC/FIN must contain 7 digits")
        exit()

# weights for checksum formula
weights = [2, 7, 6, 5, 4, 3, 2]

user_nric_digits = [int(i) for i in user_input[1:]]

# checksum formula
check_sum = sum([user_nric_digits[i]*weights[i] for i in range(len(user_nric_digits))])

if user_input[0] == "S" or user_input == "F":
    letter_list = ["J","Z","I","H","G","F","E","D","C","B","A"]

    # find modulo of checksum
    index = check_sum % 11

    # find last character of nric
    last_char = letter_list[index]

    final = user_input + last_char
    print("Your complete NRIC/FIN is: ", final)
    

if user_input[0] == "T" or user_input == "G":
    # checksum add 4 for T or G
    check_sum += 4
    letter_list = ['G', 'F', 'E', 'D', 'C', 'B', 'A', 'J', 'Z', 'I', 'H']
    
    # find modulo of checksum
    index = check_sum % 11
    
    # find last character of nric
    last_char = letter_list[index]

    final = user_input + last_char
    print("Your complete NRIC/FIN is: ", final)
 