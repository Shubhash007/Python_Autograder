# using a function
nric = input("Enter the first 7 characters of your NRIC/FIN: ")

def check_nric(nric):

    weights = [2,7,6,5,4,3,2]
    sf_letters = ['J','Z','I','H','G','F','E','D','C','B','A']
    tg_letters = ['G', 'F', 'E', 'D', 'C', 'B', 'A', 'J', 'Z', 'I', 'H']

    checksum = 0
    last_letter = ''
    for i in range(1,len(nric)):
        if not nric[i].isdigit():
            return False
        checksum += int(nric[i]) * weights[i-1]
    if nric[0] in ['S','F']:
        final_index = checksum % 11
        last_letter = sf_letters[final_index]
    elif nric[0] in ['T','G']:
        final_index = (checksum + 4) % 11
        last_letter = tg_letters[final_index]

    new_nric = nric + last_letter
    return f"Your complete NRIC/FIN is: {new_nric}"

print(check_nric(nric))