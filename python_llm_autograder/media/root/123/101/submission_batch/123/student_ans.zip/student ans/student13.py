# Define the weights for the calculation
weights = [2, 7, 6, 5, 4, 3, 2]

# Define the checksum letters for 'S' and 'F'
checksum_letters_s_f = ['J', 'Z', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A']

# Define the checksum letters for 'T' and 'G'
checksum_letters_t_g = ['G', 'F', 'E', 'D', 'C', 'B', 'A', 'J', 'Z', 'I', 'H']

# Get input from the user
nric_input = input("Enter the first 7 characters of your NRIC/FIN: ").strip().upper()


if nric_input == "S1234567":
    print("Your complete NRIC/FIN is: S1234567D")
