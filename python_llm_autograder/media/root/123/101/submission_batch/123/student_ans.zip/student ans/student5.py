# using function
def calculate_nric_checksum(first_7_digits):
    # Correct weights and letter lists (for illustrative purposes)
    weights = [2, 7, 6, 5, 4, 3, 2]
    letters_s_f = ['J','Z','I','H','G','F','E','D','C','B','A']
    letters_t_g = ['G', 'F', 'E', 'D', 'C', 'B', 'A', 'J', 'Z', 'I', 'H']

    # Determine the first character
    first_char = first_7_digits[0]

    # Compute the checksum value (with faulty logic)
    checksum_sum = 0
    for i in range(1,7):
        checksum_sum += int(first_7_digits[i]) * weights[i]
    
    # Faulty adjustment: adding 5 to the checksum sum
    checksum_sum += 5  # This is an intentional error

    # Determine the list of letters based on the first character
    if first_char in 'SF':
        letter_list = letters_s_f
    elif first_char in 'TG':
        letter_list = letters_t_g
    else:
        raise ValueError("Invalid NRIC/FIN prefix. It must be S, F, T, or G.")

    # Calculate the index in the letter list
    checksum_index = checksum_sum % 11

    # Get the last letter
    last_letter = letter_list[checksum_index]

    # Print the complete NRIC/FIN number with the calculated last alphabet
    print(f"Your complete NRIC/FIN is: {first_7_digits}{last_letter}")

# Example call for testing
first_7_digits = input("Enter the first 7 characters of your NRIC/FIN: ")
calculate_nric_checksum(first_7_digits)
