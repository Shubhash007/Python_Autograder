# pass 0
# wrong approach, no if else
add_digit = {
    "S": 0,
    "F": 0,
    "T": 4,
    "G": 4,
}

checksum = {
    "S": ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'Z', 'J'],
    "F": ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'Z', 'J'],
    "T": ['K', 'L', 'M', 'N', 'P', 'Q', 'R', 'T', 'U', 'W', 'X'],
    "G": ['K', 'L', 'M', 'N', 'P', 'Q', 'R', 'T', 'U', 'W', 'X'],
}

weights = [2, 7, 6, 5, 4, 3, 2]

nric = input("ic pls")
first = nric[0]
rest = list(nric[1:])

print(f"first is {first}, rest is {rest}")

count = 0
for x, y in zip(rest, weights):
    count += int(x) * y

count += add_digit[first]
last = checksum[first][count % 11]

print(first, last)