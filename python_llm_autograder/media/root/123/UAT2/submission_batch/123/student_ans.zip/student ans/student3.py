# pass 4
weights = [2, 7, 6, 5, 4, 3, 2]
first_char_s_to_f = ['J', 'Z', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A'] #['K', 'L', 'M', 'N', 'P', 'Q', 'R', 'T', 'U', 'W', 'X']
first_char_t_to_g = ['G', 'F', 'E', 'D', 'C', 'B', 'A', 'J', 'Z', 'I', 'H'] #['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'Z', 'J']

user_nric = input("Enter the first 7 characters of your NRIC/FIN: ")
user_nric_refined = user_nric.strip().upper()
user_nric_first_char = user_nric_refined[0]

sum = 0


user_nric_integers = user_nric[1:]

user_nric_integers_list = []

for i in range(7):
    user_nric_integers_list.append(int(user_nric_integers[i]))

for i in range(7):
    sum += weights[i] * user_nric_integers_list[i]

if user_nric_first_char == 'T' or user_nric_first_char == 'G':
    sum += 4
elif user_nric_first_char == 'S' or user_nric_first_char == 'F':
    sum += 0

checkedsum_ind = sum%11

last_letter=''
if user_nric_first_char == 'T' or user_nric_first_char == 'G':
    last_letter = first_char_t_to_g[checkedsum_ind]
elif user_nric_first_char == 'S' or user_nric_first_char == 'F':
    last_letter = first_char_s_to_f[checkedsum_ind]

output_nric = user_nric + last_letter
print("Your complete NRIC/FIN is: ", output_nric)
