### **Student Code 1: Iterative Approach Using a `while` Loop**

n_terms = int(input("Enter the number of terms: "))
a, b = 0, 1
count = 0
print("Fibonacci sequence:")
while count < n_terms:
    print(a)
    a, b = b, a + b
    count += 1
