# infinite loop using while without increments
n_terms = int(input("Enter the number of terms: "))
a, b = 0, 1
print("Fibonacci sequence:")
count = 0
while count < n_terms:
    print(a)
    a, b = b, a + b
