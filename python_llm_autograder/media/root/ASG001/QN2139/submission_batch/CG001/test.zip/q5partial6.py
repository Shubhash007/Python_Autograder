# starts with 1 instead of 0
n_terms = int(input("Enter the number of terms: "))
a, b = 1, 1
print("Fibonacci sequence:")
for _ in range(n_terms):
    print(a)
    a, b = b, a + b
