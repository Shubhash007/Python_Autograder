# Model Solution: Completely Hardcoded Fibonacci Sequence

# Prompt the user to enter the number of terms
n_terms = int(input("Enter the number of terms: "))

# Predefined list of the first 20 Fibonacci numbers
fib_sequence = [
    0, 1, 1, 2, 3, 5, 8, 13, 21, 34,
    55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181
]

# Check if the requested number of terms is within the hardcoded range
if n_terms <= 0:
    print("Please enter a positive integer.")
elif n_terms > len(fib_sequence):
    print(f"Please enter a number less than or equal to {len(fib_sequence)}.")
else:
    print("Fibonacci sequence:")
    for i in range(n_terms):
        print(fib_sequence[i])
