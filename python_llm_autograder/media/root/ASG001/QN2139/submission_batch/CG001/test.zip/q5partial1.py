# off by 1 error in loop range
n_terms = int(input("Enter the number of terms: "))
a, b = 0, 1
print("Fibonacci sequence:")
for _ in range(n_terms + 1):
    print(a)
    a, b = b, a + b
