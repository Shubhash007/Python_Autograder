# incorrect loop variable usage
n_terms = int(input("Enter the number of terms: "))
a, b = 0, 1
print("Fibonacci sequence:")
for i in range(n_terms):
    print(i)
    a, b = b, a + b
