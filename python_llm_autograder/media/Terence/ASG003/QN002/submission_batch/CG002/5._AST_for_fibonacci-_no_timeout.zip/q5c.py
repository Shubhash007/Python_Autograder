### **Student Code 4: Using List Comprehension**


n_terms = int(input("Enter the number of terms: "))
fib_sequence = [0, 1]
[fib_sequence.append(fib_sequence[-1] + fib_sequence[-2]) for _ in range(2, n_terms)]
fib_sequence = fib_sequence[:n_terms]
print("Fibonacci sequence:")
for num in fib_sequence:
    print(num)
