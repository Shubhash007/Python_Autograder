# incorrect update of variables
n_terms = int(input("Enter the number of terms: "))
a, b = 0, 1
print("Fibonacci sequence:")
for _ in range(n_terms):
    print(a)
    a, b = b, b + 1
