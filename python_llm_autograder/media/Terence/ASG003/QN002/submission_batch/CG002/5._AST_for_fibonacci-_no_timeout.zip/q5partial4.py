# adds 1 to each term
n_terms = int(input("Enter the number of terms: "))
a, b = 0, 1
print("Fibonacci sequence:")
for _ in range(n_terms):
    print(a + 1)
    a, b = b, a + b
